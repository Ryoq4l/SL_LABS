This is a secret file with confidential information.
